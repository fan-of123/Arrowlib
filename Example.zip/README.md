This datapack contains 4 custom arrows and 3 custom bows.

These are the arrows: Strong (extra damage), Black (extra damage when used with ironwood bow), Rainbow (extra damage + particle effects), Antigrav (Anti-Gravity, consumed by the infinity enchantment)

These are the bows: Ironwood (draws out the full strength of Black arrows), Hurricane (shoots 5 arrows), Inferno (turns normal arrows into Inferno Arrows. custom arrows gain a damage boost but are otherwise unaffected)